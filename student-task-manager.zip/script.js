/**
 * ======================================================
 * Student Task Manager - script.js
 * ======================================================
 * This script controls the logic and interactivity of our website.
 * It handles:
 * 1. Adding new tasks
 * 2. Viewing and displaying tasks
 * 3. Marking tasks as completed or pending
 * 4. Deleting tasks with a confirmation step
 * 5. Saving and loading tasks from the browser's Local Storage
 * 6. Updating the counters (Total, Pending, Completed)
 * 7. Showing an empty state when there are no tasks
 */

// Key used to store tasks in the browser's localStorage
const STORAGE_KEY = 'student_task_manager_tasks';

// In-memory array of task objects
let tasks = [];

// Current filter state ('all', 'pending', or 'completed')
let currentFilter = 'all';

// Track which task ID is currently pending deletion in the modal
let taskToDeleteId = null;

// ======================================================
// DOM Elements (Grabbing HTML elements to manipulate them)
// ======================================================
const taskForm = document.getElementById('task-form');
const taskNameInput = document.getElementById('task-name');
const taskSubjectInput = document.getElementById('task-subject');
const taskDueDateInput = document.getElementById('task-due-date');
const formError = document.getElementById('form-error');

const totalCountEl = document.getElementById('total-count');
const pendingCountEl = document.getElementById('pending-count');
const completedCountEl = document.getElementById('completed-count');

const taskListContainer = document.getElementById('task-list');
const emptyStateEl = document.getElementById('empty-state');
const filterButtons = document.querySelectorAll('.filter-btn');

// Modal Elements
const deleteModal = document.getElementById('delete-modal');
const cancelDeleteBtn = document.getElementById('cancel-delete-btn');
const confirmDeleteBtn = document.getElementById('confirm-delete-btn');

// ======================================================
// Storage Functions (Local Storage)
// ======================================================

/**
 * Loads tasks saved in the browser's Local Storage.
 * If no tasks exist yet, returns an empty array.
 */
function loadTasksFromStorage() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
            tasks = JSON.parse(stored);
        } else {
            tasks = [];
        }
    } catch (error) {
        console.error('Error loading tasks from Local Storage:', error);
        tasks = [];
    }
}

/**
 * Saves current tasks array into the browser's Local Storage.
 */
function saveTasksToStorage() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (error) {
        console.error('Error saving tasks to Local Storage:', error);
    }
}

// ======================================================
// Helper Functions
// ======================================================

/**
 * Safely escapes HTML special characters to prevent display issues.
 */
function escapeHTML(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

/**
 * Formats a date string (YYYY-MM-DD) into a friendly readable format (e.g. "Oct 25, 2026")
 */
function formatDueDate(dateString) {
    if (!dateString) return 'No due date';
    try {
        // Parse the year, month, day directly to avoid timezone shift
        const parts = dateString.split('-');
        if (parts.length === 3) {
            const date = new Date(parts[0], parts[1] - 1, parts[2]);
            return date.toLocaleDateString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        }
        return dateString;
    } catch (e) {
        return dateString;
    }
}

/**
 * Shows an error message above the form
 */
function showError(message) {
    formError.textContent = message;
    formError.classList.remove('hidden');
}

/**
 * Clears any error message from the form
 */
function clearError() {
    formError.textContent = '';
    formError.classList.add('hidden');
}

// ======================================================
// Rendering Functions
// ======================================================

/**
 * Updates the summary statistics counters on the dashboard
 */
function updateCounters() {
    const total = tasks.length;
    const completed = tasks.filter(t => t.completed).length;
    const pending = total - completed;

    totalCountEl.textContent = total;
    completedCountEl.textContent = completed;
    pendingCountEl.textContent = pending;
}

/**
 * Main render function: updates counters and paints task cards to the screen.
 */
function render() {
    // 1. Update the counters
    updateCounters();

    // 2. Filter tasks according to the active filter tab
    let filteredTasks = tasks;
    if (currentFilter === 'pending') {
        filteredTasks = tasks.filter(t => !t.completed);
    } else if (currentFilter === 'completed') {
        filteredTasks = tasks.filter(t => t.completed);
    }

    // 3. Clear existing list items
    taskListContainer.innerHTML = '';

    // 4. Handle Empty State
    if (filteredTasks.length === 0) {
        emptyStateEl.classList.remove('hidden');
        if (tasks.length > 0 && (currentFilter === 'pending' || currentFilter === 'completed')) {
            emptyStateEl.querySelector('h3').textContent = `No ${currentFilter} tasks found.`;
            emptyStateEl.querySelector('p').textContent = `Try switching filters or adding new tasks.`;
        } else {
            emptyStateEl.querySelector('h3').textContent = 'No tasks yet. Add your first task!';
            emptyStateEl.querySelector('p').textContent = 'Use the form above to add an assignment, homework, or exam deadline.';
        }
    } else {
        emptyStateEl.classList.add('hidden');
    }

    // 5. Build and append each task card
    filteredTasks.forEach(task => {
        const card = document.createElement('div');
        card.className = `task-card ${task.completed ? 'is-completed' : ''}`;
        card.setAttribute('data-id', task.id);

        // Status badge setup
        const statusBadge = task.completed
            ? `<span class="badge badge-completed">✓ Completed</span>`
            : `<span class="badge badge-pending">⏳ Pending</span>`;

        // Toggle button setup (Mark Complete vs Mark Pending)
        const toggleBtnHtml = task.completed
            ? `<button class="btn btn-pending" onclick="toggleTaskStatus('${task.id}')" title="Mark this task as pending">
                 ↺ Mark Pending
               </button>`
            : `<button class="btn btn-complete" onclick="toggleTaskStatus('${task.id}')" title="Mark this task as complete">
                 ✓ Mark Complete
               </button>`;

        // Card HTML structure
        card.innerHTML = `
            <div class="task-content">
                <h3 class="task-title">${escapeHTML(task.name)}</h3>
                <div class="task-meta">
                    <span class="badge badge-subject">📚 ${escapeHTML(task.subject)}</span>
                    <span class="task-due">
                        📅 Due: ${formatDueDate(task.dueDate)}
                    </span>
                    ${statusBadge}
                </div>
            </div>
            <div class="task-actions">
                ${toggleBtnHtml}
                <button class="btn btn-delete" onclick="openDeleteModal('${task.id}')" title="Delete this task">
                    🗑 Delete
                </button>
            </div>
        `;

        taskListContainer.appendChild(card);
    });
}

// ======================================================
// Task Actions (Add, Toggle, Delete)
// ======================================================

/**
 * Handles adding a new task when the form is submitted.
 */
function handleAddTask(e) {
    e.preventDefault(); // Prevent page reload on form submit

    const name = taskNameInput.value.trim();
    const subject = taskSubjectInput.value.trim();
    const dueDate = taskDueDateInput.value;

    // Validation: make sure all fields are filled
    if (!name) {
        showError('Please enter a task name.');
        taskNameInput.focus();
        return;
    }

    if (!subject) {
        showError('Please enter a subject or course.');
        taskSubjectInput.focus();
        return;
    }

    if (!dueDate) {
        showError('Please select a due date.');
        taskDueDateInput.focus();
        return;
    }

    // Clear any previous error message
    clearError();

    // Create a new task object
    const newTask = {
        id: 'task_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
        name: name,
        subject: subject,
        dueDate: dueDate,
        completed: false,
        createdAt: new Date().toISOString()
    };

    // Add to the beginning of our array so newer tasks show on top
    tasks.unshift(newTask);

    // Save to Local Storage
    saveTasksToStorage();

    // Re-render the UI
    render();

    // Reset the form inputs
    taskForm.reset();
}

/**
 * Toggles a task between completed and pending
 */
window.toggleTaskStatus = function(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    task.completed = !task.completed;

    saveTasksToStorage();
    render();
};

/**
 * Opens the delete confirmation modal
 */
window.openDeleteModal = function(taskId) {
    taskToDeleteId = taskId;
    deleteModal.classList.remove('hidden');
};

/**
 * Closes the delete confirmation modal
 */
function closeDeleteModal() {
    taskToDeleteId = null;
    deleteModal.classList.add('hidden');
}

/**
 * Confirms deletion of the selected task
 */
function confirmDelete() {
    if (!taskToDeleteId) return;

    // Filter out the task with the matching ID
    tasks = tasks.filter(t => t.id !== taskToDeleteId);

    // Save updated list to Local Storage
    saveTasksToStorage();

    // Close the modal
    closeDeleteModal();

    // Re-render the UI
    render();
}

// ======================================================
// Event Listeners & Initialization
// ======================================================

// Form submission listener
taskForm.addEventListener('submit', handleAddTask);

// Modal button listeners
cancelDeleteBtn.addEventListener('click', closeDeleteModal);
confirmDeleteBtn.addEventListener('click', confirmDelete);

// Close modal if user clicks outside the modal dialog box
deleteModal.addEventListener('click', (e) => {
    if (e.target === deleteModal) {
        closeDeleteModal();
    }
});

// Filter button tab listeners
filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        filterButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentFilter = btn.getAttribute('data-filter');
        render();
    });
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadTasksFromStorage();
    render();
});
