# Student Task Manager 🎓

A modern, clean, and responsive web application designed to help students organize their assignments, projects, exams, and daily academic tasks.

---

## 🚀 Features

- **Add Tasks**: Enter a task name, subject/course, and due date.
- **View Tasks**: Displays tasks in organized cards with subject badges and formatted dates.
- **Mark Complete / Pending**: Easily toggle task completion status. Completed tasks are visually distinguished with strikethrough titles and emerald tags.
- **Delete Tasks**: Delete tasks with a confirmation popup to prevent accidental loss.
- **Local Storage Persistence**: Automatically saves all tasks directly in the browser's Local Storage so your data remains safe across browser refreshes and restarts.
- **Live Counter Dashboard**: Real-time counters showing Total Tasks, Pending Tasks, and Completed Tasks.
- **Task Filters**: Filter by All, Pending, or Completed.
- **Responsive Design**: Clean and polished layout optimized for smartphones, tablets, and desktop computers.

---

## 📁 Project Structure

```
student-task-manager/
│
├── index.html       # Website structure & layout
├── style.css        # Modern design, colors, cards, and responsive styling
└── script.js        # Dynamic logic, event handling, and Local Storage
```

---

## 💻 How to Run

### Method 1: Double-Click (Easiest)
Simply double-click `index.html` to open the website in your default web browser (Chrome, Edge, Firefox, or Safari). No installation or server required!

### Method 2: Local Python Server (Optional)
If you have Python installed:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000` in your web browser.

---

## 🛠️ Built With

- **HTML5**
- **CSS3** (CSS Variables, Flexbox, CSS Grid)
- **Vanilla JavaScript** (ES6+, DOM API, LocalStorage)
